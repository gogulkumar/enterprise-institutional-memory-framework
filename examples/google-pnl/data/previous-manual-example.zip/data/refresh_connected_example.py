"""Refresh the readable historical numbers; no brain entries are modified."""
from pathlib import Path
import csv
root=Path(__file__).resolve().parents[1]
with (root/'data/quarterly_pnl.csv').open() as f: pnl={r['period']:r for r in csv.DictReader(f)}
with (root/'data/transcript_metrics.csv').open() as f: supplemental=list(csv.DictReader(f))
rows=[]
for s in supplemental:
 p=pnl[s['period']]; prior=pnl[str(int(s['period'][:4])-1)+s['period'][4:]]
 v=lambda k:float(p[k])
 cloud_margin=v('oi_cloud')/v('cloud')*100
 margin=v('oi_total')/v('total_revenues')*100
 adj=(v('oi_total')+float(s['ec_charge_m']))/v('total_revenues')*100
 assert abs(sum(v(k) for k in ['oi_services','oi_cloud','oi_other_bets','oi_alphabet_level'])-v('oi_total'))<1e-8
 row={'period':s['period'],'cloud_revenue_m':int(v('cloud')),'cloud_revenue_yoy_pct':round((v('cloud')/float(prior['cloud'])-1)*100,2),'cloud_margin_pct':round(cloud_margin,2),'reported_consolidated_margin_pct':round(margin,2),'EC_charge_adjusted_margin_pct':round(adj,2),**{k:float(s[k]) for k in ['depreciation_m','capex_m','backlog_m']}}
 rows.append(row)
assert round(rows[0]['cloud_margin_pct'],1)==20.7
assert round(rows[1]['cloud_margin_pct'],1)==23.7
assert round(rows[1]['EC_charge_adjusted_margin_pct'],1)==33.9
# Exact published reconciliation, rather than only a rounded headline match.
q3=pnl['2025-Q3']
q3extra=next(x for x in supplemental if x['period']=='2025-Q3')
assert float(q3['oi_total'])+float(q3extra['ec_charge_m'])==34685
# Keep the Cloud disclosure separate from broader filing remaining obligations.
assert float(q3extra['backlog_m'])==155000
assert float(q3extra['alphabet_rpo_m'])==157700
assert float(q3extra['rpo_recognition_horizon_months'])==24
out=root/'data/connected_numbers.csv'
with out.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('Refreshed',out,'from the two source tables. Arithmetic reconciled; this is not an agent performance score.')
