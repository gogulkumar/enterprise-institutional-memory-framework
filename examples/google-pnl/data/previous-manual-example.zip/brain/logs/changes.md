---
name: brain-change-log
description: Append-only list of every change applied to this brain, one line per change giving the date, the entry changed, before and after, the reason and what caused it. Use when auditing why an entry looks the way it does; only the applier writes to it.
metadata:
  last_modified: "2026-11-14"
---

# Change log

One line per change:
`CH-<ULID> | date | entry | before | after | reason | caused_by`

CH-01KGP000000000000000000001 | 2026-11-14 | SRC-01KGP000000000000000000001 | none | created (artifact) | registers the source of every reported figure | v2 migration of the v1 example
CH-01KGP000000000000000000002 | 2026-11-14 | SRC-01KGP000000000000000000002 | none | created (artifact) | registers the working dataset that checks are run against | v2 migration of the v1 example
CH-01KGP000000000000000000003 | 2026-11-14 | SRC-01KGP000000000000000000003 | none | created (tool_contract) | registers what the data tool can and cannot establish | v2 migration of the v1 example
CH-01KGP000000000000000000004 | 2026-11-14 | SRC-01KGP000000000000000000004 | none | created (authority_rule) | says which source wins for reported figures | v2 migration of the v1 example
CH-01KGP000000000000000000005 | 2026-11-14 | SRC-01KGP000000000000000000005 | none | created (approved_location) | approves the example data folder | v2 migration of the v1 example
CH-01KGP000000000000000000006 | 2026-11-14 | SRC-01KGP000000000000000000006 | none | created (artifact) | pasted note walkthrough, | pasted note
CH-01KGP000000000000000000007 | 2026-11-14 | KB-01KGP000000000000000000001 | none | created (concept) | concept from the v1 business understanding | v2 migration of the v1 example
CH-01KGP000000000000000000008 | 2026-11-14 | KB-01KGP000000000000000000002 | none | created (concept) | concept from the v1 business understanding | v2 migration of the v1 example
CH-01KGP000000000000000000009 | 2026-11-14 | KB-01KGP000000000000000000003 | none | created (concept) | concept from the v1 business understanding | v2 migration of the v1 example
CH-01KGP000000000000000000010 | 2026-11-14 | KB-01KGP000000000000000000004 | none | created (concept) | concept from the v1 business understanding | v2 migration of the v1 example
CH-01KGP000000000000000000011 | 2026-11-14 | KB-01KGP000000000000000000005 | none | created (metric_definition) | metric definition validated: segment operating income plus Alphabet-level activities equals reported consolidated operating income in all 12 quarters | v2 migration of the v1 example
CH-01KGP000000000000000000012 | 2026-11-14 | KB-01KGP000000000000000000006 | none | created (known_issue) | known issue split out of the v1 metric definition | v2 migration of the v1 example
CH-01KGP000000000000000000013 | 2026-11-14 | KB-01KGP000000000000000000007 | none | created (known_issue) | known issue split out of the v1 metric definition | v2 migration of the v1 example
CH-01KGP000000000000000000014 | 2026-11-14 | KB-01KGP000000000000000000008 | none | created (source_of_truth) | source of truth from the v1 authority rule | v2 migration of the v1 example
CH-01KGP000000000000000000015 | 2026-11-14 | KB-01KGP000000000000000000009 | none | created (deliverable_profile) | deliverable profile from the v1 Lens | v2 migration of the v1 example
CH-01KGP000000000000000000016 | 2026-11-14 | KB-01KGP000000000000000000010 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000017 | 2026-11-14 | KB-01KGP000000000000000000011 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000018 | 2026-11-14 | KB-01KGP000000000000000000012 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000019 | 2026-11-14 | KB-01KGP000000000000000000013 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000020 | 2026-11-14 | KB-01KGP000000000000000000014 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000021 | 2026-11-14 | KB-01KGP000000000000000000015 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000022 | 2026-11-14 | KB-01KGP000000000000000000016 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000023 | 2026-11-14 | KB-01KGP000000000000000000017 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000024 | 2026-11-14 | KB-01KGP000000000000000000018 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000025 | 2026-11-14 | KB-01KGP000000000000000000019 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000026 | 2026-11-14 | KB-01KGP000000000000000000020 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000027 | 2026-11-14 | KB-01KGP000000000000000000021 | none | created (business_event) | registers the event for one quarter's release | v2 migration of the v1 example
CH-01KGP000000000000000000028 | 2026-11-14 | BV-01KGP000000000000000000001 | none | created (business_view, trust established) | normal range from the v1 Normality, established by cases with a data check | v2 migration of the v1 example
CH-01KGP000000000000000000029 | 2026-11-14 | BV-01KGP000000000000000000002 | none | created (business_view, trust established) | normal range from the v1 Normality, established by cases with a data check | v2 migration of the v1 example
CH-01KGP000000000000000000030 | 2026-11-14 | BV-01KGP000000000000000000003 | none | created (business_view, trust established) | normal range from the v1 Normality, established by cases with a data check | v2 migration of the v1 example
CH-01KGP000000000000000000031 | 2026-11-14 | BV-01KGP000000000000000000004 | none | created (business_view, trust established) | normal range from the v1 Normality, established by cases with a data check | v2 migration of the v1 example
CH-01KGP000000000000000000032 | 2026-11-14 | BV-01KGP000000000000000000005 | none | created (business_view, trust candidate) | pattern from v1 belief; candidate until the owner ratifies | v2 migration of the v1 example
CH-01KGP000000000000000000033 | 2026-11-14 | BV-01KGP000000000000000000006 | none | created (business_view, trust candidate) | pattern from v1 belief; candidate until the owner ratifies | v2 migration of the v1 example
CH-01KGP000000000000000000034 | 2026-11-14 | BV-01KGP000000000000000000007 | none | created (business_view, trust candidate) | pattern from v1 belief; candidate until the owner ratifies | v2 migration of the v1 example
CH-01KGP000000000000000000035 | 2026-11-14 | DM-01KGP000000000000000000001 | none | created (link, trust established) | v1 `constrains` link mapped to `offsets`, the v2 type the calculation supports | v2 migration of the v1 example
CH-01KGP000000000000000000036 | 2026-11-14 | DM-01KGP000000000000000000002 | none | created (link, trust established) | v1 `independent` link kept as `independent` | v2 migration of the v1 example
CH-01KGP000000000000000000037 | 2026-11-14 | TP-01KGP000000000000000000001 | none | created (thinking_pattern, trust observation) | placeholder from the v1 inquiry chain; never confirmed by a real owner | v2 migration of the v1 example
CH-01KGP000000000000000000038 | 2026-11-14 | JD-01KGP000000000000000000001 | none | created (judgment, trust observation) | placeholder from the v1 stopping rule; never confirmed by a real owner | v2 migration of the v1 example
CH-01KGP000000000000000000039 | 2026-11-14 | RS-01KGP000000000000000000001 | none | created (response_style, trust observation) | placeholder from the v1 editorial rule; never confirmed by a real owner | v2 migration of the v1 example
CH-01KGP000000000000000000040 | 2026-11-14 | PR-01KGP000000000000000000001 | none | created (procedure, trust observation) | procedure from the v1 Lens; never confirmed by a real owner | v2 migration of the v1 example
CH-01KGP000000000000000000041 | 2026-11-14 | TP-01KGP000000000000000000002 | none | created (thinking_pattern, trust established) | pasted note walkthrough, | pasted note
CH-01KGP000000000000000000042 | 2026-11-14 | JD-01KGP000000000000000000002 | none | created (judgment, trust established) | pasted note walkthrough, | pasted note
CH-01KGP000000000000000000043 | 2026-11-14 | JD-01KGP000000000000000000003 | none | created (judgment, trust established) | pasted note walkthrough, | pasted note
CH-01KGP000000000000000000044 | 2026-11-14 | RS-01KGP000000000000000000002 | none | created (response_style, trust established) | pasted note walkthrough, | pasted note
CH-01KGP000000000000000000045 | 2026-11-14 | Q-01KGP000000000000000000001 | none | created (question) | story thread from v1, now a watch question | v2 migration of the v1 example
CH-01KGP000000000000000000046 | 2026-11-14 | Q-01KGP000000000000000000002 | none | created (question) | pasted note walkthrough, | pasted note
CH-01M7ERAFWFTFB1MQGYJRPAQDBA | 2026-11-14 | SRC-01M7ERAFWCHR0H097B4ZE88XFJ | absent | created | transcript diagnostic additive batch | LP-01M7ERAFWCBP0YP5AKZMKA5FH7
CH-01M7ERAFWGVZKV5Y8JGEB5DXVX | 2026-11-14 | SRC-01M7ERAFWCSSZD3N1BC65MNWGG | absent | created | transcript diagnostic additive batch | LP-01M7ERAFWCBP0YP5AKZMKA5FH7
CH-01M7ERAFWHQBT1MKSW53PD8BBV | 2026-11-14 | SRC-01M7ERAFWCHEJ43VEJZ2TP3XAA | absent | created | transcript diagnostic additive batch | LP-01M7ERAFWCBP0YP5AKZMKA5FH7
CH-01M7ERAFWKB0705GXAMQ7Z15W6 | 2026-11-14 | BV-01M7ERAFWDKBHQ9NEM4M6CPKYJ | absent | created | transcript diagnostic additive batch | LP-01M7ERAFWCBP0YP5AKZMKA5FH7
CH-01M7ERAFWM5P7QQX26FGS186AN | 2026-11-14 | KB-01M7ERAFWDGJ14VH9JRX8AQ7AE | absent | created | transcript diagnostic additive batch | LP-01M7ERAFWCBP0YP5AKZMKA5FH7
CH-01M7ES2J74PSKESMWMMZF09TC6 | 2026-11-14 | SRC-01M7ES2HYDTTN0J5N54MWW8ZQ9 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J752XDYQXFNF8C5X3J5 | 2026-11-14 | SRC-01M7ES2HYDBMJVD4128NGBS8JK | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7690B49WRCKB0YABX6 | 2026-11-14 | KB-01M7ES2HYDMEANZAVX351Y8FXJ | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J78JSD72ESB0AEGKEDD | 2026-11-14 | KB-01M7ES2HYDJE1NGX01210SMX3P | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J79DECH040YX6CCYPEM | 2026-11-14 | KB-01M7ES2HYDTVSRQB5A8H16T5XM | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7AZ5RS68T6NYJVG9J9 | 2026-11-14 | KB-01M7ES2HYD811555MZ92RS90Q8 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7B4VFQZ0VBFJ88Y019 | 2026-11-14 | KB-01M7ES2HYDS837AKRBNH3BWP57 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7DAAE7XGT4B9C6V82T | 2026-11-14 | KB-01M7ES2HYD1TNSJ14CCG9P5262 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7E8DNJ8C5SC1Z7PQBM | 2026-11-14 | KB-01M7ES2HYDGWTRA9WBEVD565FJ | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7FQ94H2C828H2VZH19 | 2026-11-14 | KB-01M7ES2HYD56QDV4BZT9K2M0EB | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7H7CNPMKRKNAP0D7DJ | 2026-11-14 | KB-01M7ES2HYD1WT2MC3RAN3VPJR9 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7JT3TEREDKW33N7TP3 | 2026-11-14 | KB-01M7ES2HYDXRE4EZEAW8CPBM0F | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7MNTM04ADQSV3VX34Y | 2026-11-14 | KB-01M7ES2HYDG46W8BB30G5CKJ7R | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7P8ER0YZ4H7Y7111FF | 2026-11-14 | BV-01M7ES2HYD9QS0G6377EYMWNV6 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7RYY42H4GT2H1489NA | 2026-11-14 | BV-01M7ES2HYD0ET94GDMQC5TWYAT | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7T8GEET5525ZTTM7EE | 2026-11-14 | JD-01M7ES2HYDZX3126GJWWZGV8DS | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7VVERXHM4GCK1B0G53 | 2026-11-14 | JD-01M7ES2HYD1AE0FZ1SH0HKABH6 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J7XTRZS4XASAWQ1DS2D | 2026-11-14 | JD-01M7ES2HYD0S1E38NXGWMQXT5G | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J81EQ8QNWWP313P33BC | 2026-11-14 | TP-01M7ES2HYD5C67T196ZHZ6KJMG | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J83EN2X7C37MZGH6BW6 | 2026-11-14 | RS-01M7ES2HYDV686NQVJPWJ7QE18 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J84C4CRQBM644NJ2FSA | 2026-11-14 | DM-01M7ES2HYD81D6NJM3M9RQE7NB | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J851C9YSANS2AJJ6AM3 | 2026-11-14 | DM-01M7ES2HYD6NNV5FARCF0A3XQD | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J87P0SGB539YEW16ATY | 2026-11-14 | DM-01M7ES2HYDVFSXTFJ9H5X9MNVX | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J89YQAG0VDW5990JCDN | 2026-11-14 | PR-01M7ES2HYDGHS7VPYWP5CX0AE6 | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ES2J8BJAE94ERR7GNVG2B9 | 2026-11-14 | KB-01M7ES2HYDTQD4HQXFR938H6NF | absent | created | connected public earnings example; inferred practices remain observations | LP-01M7ES2HY21EATGP78JXRTB21H
CH-01M7ESNY1YAJYVHVSMNPRVTNYZ | 2026-11-14 | SRC-01M7ESNXN93WR2NCNA8EPBQ9K3 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y1TPD47FM2C1E179Z | 2026-11-14 | SRC-01M7ESNXN93SEW3AZX79MQG1K5 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YHY0JX41KTNEBMSKT | 2026-11-14 | SRC-01M7ESNXN9N0M4B6APP2JHK4HR | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YV7AP6EZP2FQ4XGFM | 2026-11-14 | KB-01KGP000000000000000000001 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y51EQ62EMYVR9F7PX | 2026-11-14 | KB-01KGP000000000000000000002 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YJ63CQ1Y4WDES98H2 | 2026-11-14 | KB-01KGP000000000000000000003 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YNCTWRDZG9K3705R8 | 2026-11-14 | KB-01KGP000000000000000000004 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YAHE3XVRDWR7R76CZ | 2026-11-14 | KB-01M7ES2HYDMEANZAVX351Y8FXJ | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y5FHXW6EZSF01EC97 | 2026-11-14 | KB-01M7ES2HYDJE1NGX01210SMX3P | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YS1M1HM9ZNZCHY30G | 2026-11-14 | KB-01M7ES2HYD811555MZ92RS90Q8 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y4BSN2P1B66VJK81C | 2026-11-14 | KB-01M7ES2HYDTVSRQB5A8H16T5XM | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YF4RCFV1AT22Z745T | 2026-11-14 | KB-01KGP000000000000000000005 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YZD83RTTMAH42GVVH | 2026-11-14 | KB-01M7ES2HYDS837AKRBNH3BWP57 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YV2XWMSZ3R0AM1759 | 2026-11-14 | KB-01M7ES2HYD1TNSJ14CCG9P5262 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y5S7H231DA5FQHE8S | 2026-11-14 | KB-01M7ES2HYD56QDV4BZT9K2M0EB | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y4K3SRYSCNJA6E5XZ | 2026-11-14 | KB-01M7ES2HYDGWTRA9WBEVD565FJ | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YPWPN0ZDA3DFCMP5R | 2026-11-14 | KB-01M7ES2HYD1WT2MC3RAN3VPJR9 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YKTYKPN5RFHNSB82Q | 2026-11-14 | KB-01M7ES2HYDXRE4EZEAW8CPBM0F | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YQYTR9W7QQ4EVF8H6 | 2026-11-14 | KB-01KGP000000000000000000006 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y2GTFPZACKY38JPNN | 2026-11-14 | KB-01KGP000000000000000000007 | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1YRXRVY2WJDT3JK2XS | 2026-11-14 | KB-01M7ERAFWDGJ14VH9JRX8AQ7AE | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
CH-01M7ESNY1Y01Y1V16XCVH8B08N | 2026-11-14 | KB-01M7ES2HYDG46W8BB30G5CKJ7R | prior content retained in archive where applicable | detailed sourced explanation or source added | user-authorized knowledge correction and enrichment | LP-01M7ESNXMEKG17A5FEFCKPPSWV
